	    <footer class="pieddepage">
			<div>
				<div class="copyright">

					  PROJET AOS | Version 1.0.0
				</div>
			</div>
	    </footer>

		<script src="bootstrap/js/bootstrap.min.js"></script>
	</body>
</html>