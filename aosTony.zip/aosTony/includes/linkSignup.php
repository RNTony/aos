<?php

$h1 ="Profiter de vos amis &amp; famille  <br/> Via les souvenirs inoubliables!";
$p1 ="Utilisé par ????? PintAOSEURS à travers le monde !";
$p2 ="Reliable contracts, multifanctionality &amp; best usage of Unify template";
$p3 ="Secure &amp; integrated options to create individual &amp; business websites";
$blockquote ="Look no further you came to the right place. <br/>Unify offers everything you have dreamed of in one package.";
$h4 ="Alex Pottorf";
$em ="Web Developer";

?>
